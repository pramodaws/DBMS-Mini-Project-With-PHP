How to run Directory Management System (DMS) Project
1. Download the zip file.
2. Extract the file and copy the dms folder.
3.Paste inside root directory(for xampp xampp/htdocs, for wamp wamp/www, for lamp var/www/HTML)
4. Open PHPMyAdmin (http://localhost/phpmyadmin)
5. Create a database with the name dmsdb.
6. Import dmsdb.sql file(given inside the zip package in the SQL file folder).
7. Run the script http://localhost/dms(frontend).
8. For admin panel http://localhost/dms/admin  (admin panel).
Credential for admin panel :
username: admin
