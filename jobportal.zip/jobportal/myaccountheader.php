
<div style="width:1048px; height:120px; background-color:#FFFFFF;border:solid 0px #FF0000;">


<div style="width:730px; height:20px; background-color:#FFFFFF; border:solid 0px #990000; margin-left:220px;">
<?php include('headermenu.php');?>
</div>
<div style=" width:1048px; height:80px; border:#339933 0px solid;">

<!--logo--><div style="width:280px; height:78px; float:left; border:solid 0px #FF0000; padding-top:2%"><a href="index.php" style="text-decoration:none; font-size:22px;">PHPGURUKUL Job Portal</a></div>

<div style="width:700px; height:78px; border: 0px solid #000000; float:left;font-family:Monotype Corsiva; font-size:12px;">

<div style="margin-left:450px; margin-top:5px; height:50px; width:280px; border-radius:0px 0px 0px 0px;box-shadow:0px 0px 0px 0px #CCCCCC; background-color:#FFFFFF;border:#000000 0px solid;">
<div style="width:270px;margin-left:10px;">
<p style="margin-top:0px;">
Welcome :
<?php
$name=$_SESSION['NAME'];
echo"<font size='5' color='blue' ><b>$name</b></font>";
?></div>
</div>
</div>

</div>
<div style="width:1045px; height:25px; color:#000084; border: 0px solid #000000; ">
<marquee behavior="scroll" direction="left" >
India Jobs &gt; Gulf Jobs &gt; IT Jobs &gt; BPO Jobs &gt; Retail Jobs &gt; Construction Jobs &gt; Advertising Jobs &gt; Sales Jobs &gt; NGO Jobs &gt; Banks Jobs &gt; Medical Jobs &gt; Fresher Jobs &gt; Management Jobs &gt; Account Jobs &gt;
</marquee>

</div>
</div>