<div style="width:1048px; height:120px; background-color:#EFEFEF;border:solid 0px #FF0000;">


<div style=" width:1048px; height:80px; border:#339933 0px solid; font-size:36px" align="center">

<!--logo-->PHPGURUKUL Job Portal Admin</div>

</div>