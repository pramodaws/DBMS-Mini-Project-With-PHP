<div style="width:730px; height:20px; border:#000000 0px solid;margin:auto;">
<link rel="stylesheet" href="css_menuheader/style.css" type="text/css" />
<style type="text/css">
._css3m{display:none}
</style>
<ul id="css3menu1" class="topmenu">
	<li class="topfirst"><a href="India_Jobs.php" style="height:20px;line-height:20px; width:70px;"><div style="padding-left:2px;">India Jobs</div></a></li>
	<li><a href="#" style="height:20px;line-height:20px; width:5px;"><div style="padding-left:0px;">|</div></a></li>
	<li class="toplast"><a href="Golf_Jobs.php" style="height:20px;line-height:20px; width:70px;"><div style="padding-left:2px;">Gulf Jobs</div></a></li>
    <li><a href="#" style="height:20px;line-height:20px; width:5px;"><div style="padding-left:0px;">|</div></a></li>
    <li class="topmenu"><a href="It_Jobs.php" style="height:20px;line-height:20px; width:60px;"><div style="padding-left:2px;">IT Jobs</div></a></li>  
    <li><a href="#" style="height:20px;line-height:20px; width:5px;"><div style="padding-left:0px;">|</div></a></li>

  <li class="topmenu"><a href="BPO_Jobs.php" style="height:20px;line-height:20px; width:70px;"><div style="padding-left:2px;">BPO Jobs</div></a></li>
  <li><a href="#" style="height:20px;line-height:20px; width:5px;"><div style="padding-left:0px;">|</div></a></li>

    
  <li class="topmenu"><a href="Retails_Jobs.php" style="height:20px;line-height:20px; width:75px;"><div style="padding-left:2px;">Retail Jobs</div></a></li>
  <li><a href="#" style="height:20px;line-height:20px; width:5px;"><div style="padding-left:0px;">|</div></a></li>
   <li class="topmenu"><a href="Construction_Jobs.php" style="height:20px;line-height:20px; width:120px;"><div style="padding-left:2px;">Constructions Jobs </div>
   </a></li>
   <li><a href="#" style="height:20px;line-height:20px; width:5px;"><div style="padding-left:0px;">|</div></a></li>
    <li class="topmenu"><a href="Advertising_Jobs.php" style="height:20px;line-height:20px; width:110px;"><div style="padding-left:2px;">Advertising Jobs</div></a></li>
	<li><a href="#" style="height:20px;line-height:20px; width:5px;"><div style="padding-left:0px;">|</div></a></li>
	<li class="topmenu"><a href="#" style="height:20px;line-height:20px; width:110px;"><div style="padding-left:2px;">HR & Management</div></a></li>
</ul>
	

</div>


